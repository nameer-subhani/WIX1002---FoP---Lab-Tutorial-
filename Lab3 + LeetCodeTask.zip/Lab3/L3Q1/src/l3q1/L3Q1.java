package l3q1;

import java.util.Scanner;

public class L3Q1 {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        System.out.print("Enter two integer number: ");
        int num1 = input.nextInt();
        int num2 = input.nextInt();
        System.out.print("Enter the operand: ");
        char op = input.next().charAt(0);

        switch (op) {
            case '+':
                System.out.println(num1 + " + " + num2 + " = " + (num1 + num2));
                break;
            case '-':
                System.out.println(num1 + " - " + num2 + " = " + (num1 - num2));
                break;
            case '*':
                System.out.println(num1 + " * " + num2 + " = " + (num1 * num2));
                break;
            case '/':
                if (num2 == 0)
                    System.out.println("Cannot divide by zero");
                else
                    System.out.println(num1 + " / " + num2 + " = " + (num1 / num2));
                break;
            case '%':
                if (num2 == 0)
                    System.out.println("Cannot divide by zero");
                else
                    System.out.println(num1 + " % " + num2 + " = " + (num1 % num2));
                break;
            default:
                System.out.println("Invalid operand");
        }
        System.out.println();
    }

}