package l3q1extratask;

import java.util.Scanner;

public class L3Q1ExtraTask {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        System.out.print("Enter two decimal number: ");
        double num1 = input.nextDouble();
        double num2 = input.nextDouble();
        System.out.print("Enter the operand: ");
        char op = input.next().charAt(0);

        switch (op) {
            case '+':
                System.out.println(num1 + " + " + num2 + " = " + (num1 + num2));
                break;
            case '-':
                System.out.println(num1 + " - " + num2 + " = " + (num1 - num2));
                break;
            case '*':
                System.out.println(num1 + " * " + num2 + " = " + (num1 * num2));
                break;
            case '/':
                if (num2 == 0)
                    System.out.println("Cannot divide by zero");
                else
                    System.out.println(num1 + " / " + num2 + " = " + (num1 / num2));
                break;
            case '%':
                if (num2 == 0)
                    System.out.println("Cannot divide by zero");
                else
                    System.out.println(num1 + " % " + num2 + " = " + (num1 % num2));
                break;
            default:
                System.out.println("Invalid operand");
        }
        System.out.println();
    }

}