package l3q4;

import java.util.Random;

public class L3Q4 {

  
    public static void main(String[] args) {
        int p1Roll1 = new Random().nextInt(6) + 1;
        int p1Roll2 = new Random().nextInt(6) + 1;
        int p2Roll1 = new Random().nextInt(6) + 1;
        int p2Roll2 = new Random().nextInt(6) + 1;
        
        int p1Score = p1Roll1 + p1Roll2;
        int p2Score = p2Roll1 + p2Roll2;
        
        System.out.println("Player 1 rolled " + p1Roll1 + " and " + p1Roll2 + " = " + p1Score);
        System.out.println("Player 2 rolled " + p2Roll1 + " and " + p2Roll2 + " = " + p2Score);
        
        if (p1Score > p2Score){
            System.out.print("Player 1 Wins");
            System.out.println();
        }else if (p2Score > p1Score){
            System.out.print("Player 2 Wins");
            System.out.println();

        }else{
            System.out.print("It's a tie");
            System.out.println();

        }
    }
    
}
