package l3q6;

import java.util.Scanner;

public class L3Q6 {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        
        System.out.print("Enter the radius of the circle: ");
        double radius = input.nextDouble();
        System.out.print("Enter the point (x, y): ");
        double x = input.nextDouble();
        double y = input.nextDouble();

        double distance = Math.sqrt(x * x + y * y);

        if (distance <= radius)
            System.out.println("The point (" + x + ", " + y + ") is inside the circle");
        else
            System.out.println("The point (" + x + ", " + y + ") is outside the circle");
        System.out.println();
    }

}