
package l3leetcodetask;

public class L3LeetCodeTask {

    public static void main(String[] args) {

        int[][] points = {{0, 0},{1, 1},{2, 3}};

        int x1 = points[0][0];
        int y1 = points[0][1];

        int x2 = points[1][0];
        int y2 = points[1][1];

        int x3 = points[2][0];
        int y3 = points[2][1];

        int left = (y2 - y1) * (x3 - x1); // I did this because if i had used normal gradient formula and x coordinate of any 2 ppoints had been same, denominator would become 0 and it would result in division error. So i just rearranged the formula like this. This rearranged formula is basically comparing gradient from two different pairs of points. like AB and AC
        int right = (y3 - y1) * (x2 - x1);

        if (left != right) {
            System.out.println(true);
        } else {
            System.out.println(false);
        }
    }
}
