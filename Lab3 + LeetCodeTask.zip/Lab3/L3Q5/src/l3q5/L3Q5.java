package l3q5;

import java.util.Scanner;

public class L3Q5 {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter a, b, c, d, e, f: ");
        
        int a = input.nextInt();
        int b = input.nextInt();
        int c = input.nextInt();
        int d = input.nextInt();
        int e = input.nextInt();
        int f = input.nextInt();
        
        int denominator = a*d - b*c;
        if (denominator == 0){
            System.out.println("The equation has no solution");
        }
        else{
            double x = (double) (e*d - b*f) / denominator;
            double y = (double) (a*f - e*c) / denominator;
            System.out.println("x = " + x);
            System.out.println("y = " + y);
        }
        System.out.println();

    }
    
}