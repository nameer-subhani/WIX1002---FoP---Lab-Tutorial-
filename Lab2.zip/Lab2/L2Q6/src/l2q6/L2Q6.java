package l2q6;

import java.util.Scanner;

public class L2Q6 {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter the amount of water in gram: ");
        double gram = input.nextDouble();

        System.out.print("Enter the initial temperature in Fahrenheit: ");
        double initialF = input.nextDouble();

        System.out.print("Enter the final temperature in Fahrenheit: ");
        double finalF = input.nextDouble();

        double kg = gram / 1000;
        double initialC = (initialF - 32) / 1.8;
        double finalC = (finalF - 32) / 1.8;

        double q = kg * (finalC - initialC) * 4184;

        System.out.printf("The energy needed is %e\n", q);
    }

}