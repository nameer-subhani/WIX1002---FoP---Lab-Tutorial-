package l2q5;

public class L2Q5 {

    public static void main(String[] args) {
      
        int number = (int) (Math.random() * 10001);
        int temp = number;
        int sum = 0;

        while (temp > 0) {
            sum = sum + temp % 10;   
            temp = temp / 10;        
        }

        System.out.println("The number is " + number);
        System.out.println("The sum of all the digits is " + sum);
    }

}