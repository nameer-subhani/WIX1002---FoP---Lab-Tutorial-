package l2q3;

public class L2Q3 {

    public static void main(String[] args) {
  
        int num1 = (int) (Math.random() * 41) + 10;
        int num2 = (int) (Math.random() * 41) + 10;
        int num3 = (int) (Math.random() * 41) + 10;

        int sum = num1 + num2 + num3;
        double average = sum / 3.0;

        System.out.println("The three numbers are " + num1 + ", " + num2 + " and " + num3);
        System.out.println("The sum is " + sum);
        System.out.printf("The average is %.2f\n", average);
    }

}